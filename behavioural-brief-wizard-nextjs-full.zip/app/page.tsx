import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-8 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-xl text-center space-y-4">
        <h1 className="text-3xl font-semibold">Behavioural Brief Wizard</h1>
        <p className="text-slate-600">Start the wizard to triage Strategy / Planning / Tactical and capture behavioural inputs.</p>
        <Link href="/brief" className="inline-flex items-center justify-center rounded-2xl px-4 py-2 bg-black text-white">Open Wizard</Link>
      </div>
    </main>
  );
}
