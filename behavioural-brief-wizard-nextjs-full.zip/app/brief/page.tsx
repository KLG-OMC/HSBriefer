'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Printer, ArrowRight, ArrowLeft, Trash2, CheckCircle2, Plus, Sparkles, ClipboardList, CircleHelp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';

const LS_KEY = 'behavioural_brief_v1';

type JourneyStage = 'awareness'|'consideration'|'conversion'|'retention'|'winback';

const defaultData = {
  meta: { projectName: '', clientOrg: '', brand: '', briefedBy: '', dateBriefed: '', responseDue: '' },
  scope: { needs: { strategy: false, planning: true, tactical: false }, notes: '' },
  business: { objective: '', market: '', budget: '', keyDates: '' },
  behaviour: {
    behaviourToday: '',
    behaviourDesired: '',
    audienceSegments: [{ name: '', who: '', dayInLife: '', barriers: '', influencers: '' }],
    blockers: { emotional: '', social: '', rational: '' }
  },
  strategyLayer: {
    askMediaTo: { reframePerception: false, shiftNorms: false, defineHypothesis: false, redefineAudience: false, setLongTermRole: false },
    pmeFocus: { perception: true, motivation: true, enablement: true },
    biases: [] as string[],
    organisingIdea: ''
  },
  planningLayer: {
    sequencing: '', phasing: '', channelMix: '', budgetFlex: '',
    journeyJobs: {
      awareness: { know: '', do: '' },
      consideration: { know: '', do: '' },
      conversion: { know: '', do: '' },
      retention: { know: '', do: '' },
      winback: { know: '', do: '' }
    } as Record<JourneyStage, {know: string; do: string}>
  },
  tacticalLayer: { executeInFlight: false, preDefinedChannels: false, performanceKpisOnly: false, platformNotes: '', testAndLearn: true },
  media: { paidOwnedEarned: '', contextualOpps: '', assetsExisting: '', assetsNeeded: '' },
  measurement: { success: '', kpis: '', instrumentation: '', cadence: '' },
  governance: { mandatories: '', regions: '', stakeholders: '' }
};

const biasOptions = [
  'Status quo bias','Loss aversion','Social proof','Availability heuristic','Framing effect','Default effect','Cognitive ease','Temporal discounting','Reciprocity','Primacy / Recency','Choice overload'
];

const steps = [
  { id: 'scope', label: 'Triage', icon: <ClipboardList className="h-4 w-4" /> },
  { id: 'business', label: 'Business', icon: <CircleHelp className="h-4 w-4" /> },
  { id: 'behaviour', label: 'Behaviour', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'strategy', label: 'Strategy', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'planning', label: 'Planning', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'tactics', label: 'Tactics', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'media', label: 'Media', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'measurement', label: 'Measurement', icon: <Sparkles className="h-4 w-4" /> },
  { id: 'review', label: 'Review & Print', icon: <CheckCircle2 className="h-4 w-4" /> }
] as const;

function useLocalState<T>(key: string, initial: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [val, setVal] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : initial; } catch { return initial; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* noop */ } }, [key, val]);
  return [val, setVal];
}

function Row({ children }: { children: React.ReactNode }) { return <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{children}</div>; }
function Field({ label, children, help }: { label: string; children: React.ReactNode; help?: string }) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      {children}
      {help ? <p className="text-xs text-slate-500">{help}</p> : null}
    </div>
  );
}

export default function BehaviouralBriefWizard() {
  const [data, setData] = useLocalState(LS_KEY, defaultData);
  const [stepIdx, setStepIdx] = useState(0);
  const [compact, setCompact] = useState(false);

  const visibleSteps = useMemo(() => {
    const enabled = {
      strategy: data.scope.needs.strategy,
      planning: data.scope.needs.planning,
      tactical: data.scope.needs.tactical
    };
    return steps.filter((s) => {
      if (s.id === 'strategy' && !enabled.strategy) return false;
      if (s.id === 'planning' && !enabled.planning) return false;
      if (s.id === 'tactics' && !enabled.tactical) return false;
      return true;
    });
  }, [data.scope.needs]);

  const activeId = visibleSteps[stepIdx].id;
  const pct = useMemo(() => ((stepIdx + 1) / visibleSteps.length) * 100, [stepIdx, visibleSteps.length]);

  useEffect(() => {
    const ids = visibleSteps.map((s) => s.id);
    if (!ids.includes(activeId)) {
      setStepIdx(Math.min(stepIdx, visibleSteps.length - 1));
    }
  }, [visibleSteps]);

  const set = (path: string, value: any) => {
    setData((prev) => {
      const next = structuredClone(prev);
      const keys = path.split('.');
      // @ts-ignore
      let ref = next;
      for (let i = 0; i < keys.length - 1; i++) ref = ref[keys[i]];
      // @ts-ignore
      ref[keys.at(-1)!] = value;
      return next;
    });
  };

  const addAudience = () => set('behaviour.audienceSegments', [...data.behaviour.audienceSegments, { name: '', who: '', dayInLife: '', barriers: '', influencers: '' }]);
  const removeAudience = (i: number) => { const arr = [...data.behaviour.audienceSegments]; arr.splice(i, 1); set('behaviour.audienceSegments', arr); };
  const go = (dir: number) => { const n = stepIdx + dir; if (n >= 0 && n < visibleSteps.length) setStepIdx(n); };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${data?.meta?.projectName || 'behavioural_brief'}.json`; a.click(); URL.revokeObjectURL(url);
  };
  const printDoc = () => window.print();

  const renderHeader = () => (
    <div className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
        <span className="rounded-2xl bg-slate-100 px-3 py-1 text-xs">Media Behavioural Brief</span>
        <div className="hidden md:block w-1/2"><Progress value={pct} /></div>
        <div className="ml-auto flex items-center gap-2 print:hidden">
          <div className="flex items-center gap-2">
            <Label className="text-xs text-slate-600">Compact</Label>
            <Switch checked={compact} onCheckedChange={setCompact} />
          </div>
          <Button variant="outline" size="sm" onClick={exportJson}><Download className="h-4 w-4"/>Export JSON</Button>
          <Button size="sm" onClick={printDoc}><Printer className="h-4 w-4"/>Print</Button>
        </div>
      </div>
    </div>
  );

  const StepShell = ({ title, children, subtitle }: { title: string; subtitle?: string; children: React.ReactNode }) => (
    <Card>
      <CardHeader>
        <CardTitle><Sparkles className="h-5 w-5" /> <span>{title}</span></CardTitle>
        {subtitle ? <p className="text-sm text-slate-600">{subtitle}</p> : null}
      </CardHeader>
      <CardContent className={compact ? 'space-y-4' : 'space-y-6'}>{children}</CardContent>
    </Card>
  );

  const StepControls = () => (
    <div className="flex justify-between items-center gap-2 print:hidden">
      <Button variant="outline" onClick={() => go(-1)} disabled={stepIdx === 0}><ArrowLeft className="h-4 w-4"/>Back</Button>
      <div className="flex items-center gap-2">
        <Button variant="ghost" onClick={() => setData(defaultData)}><Trash2 className="h-4 w-4"/>Reset</Button>
        <Button onClick={() => go(1)} disabled={stepIdx >= visibleSteps.length - 1}>Next<ArrowRight className="h-4 w-4"/></Button>
      </div>
    </div>
  );

  const StrategyHints = () => (
    <div className="grid md:grid-cols-3 gap-3">
      {Object.entries(data.strategyLayer.askMediaTo).map(([k, v]) => (
        <label key={k} className="flex items-start gap-2 rounded-2xl border p-3">
          <Checkbox checked={v} onCheckedChange={(val) => set(`strategyLayer.askMediaTo.${k}`, !!val)} />
          <span className="text-sm">
            {k === 'reframePerception' && 'Reframe category/brand perception via media'}
            {k === 'shiftNorms' && 'Shift social norms / mental availability'}
            {k === 'defineHypothesis' && 'Define a unifying behavioural media hypothesis'}
            {k === 'redefineAudience' && 'Redefine / prioritise growth audiences'}
            {k === 'setLongTermRole' && 'Set media’s long-term role in growth'}
          </span>
        </label>
      ))}
    </div>
  );

  const PMESelector = () => (
    <div className="flex flex-wrap gap-2">
      {Object.entries(data.strategyLayer.pmeFocus).map(([k, v]) => (
        <label key={k} className={`px-3 py-2 rounded-2xl border cursor-pointer ${v ? 'bg-slate-100' : ''}`}>
          <input type="checkbox" className="hidden" checked={v} onChange={(e) => set(`strategyLayer.pmeFocus.${k}`, e.target.checked)} />
          <span className="text-sm capitalize">{k}</span>
        </label>
      ))}
    </div>
  );

  const BiasSelector = () => (
    <div className="flex flex-wrap gap-2">
      {biasOptions.map((b) => {
        const on = data.strategyLayer.biases.includes(b);
        return (
          <button type="button" key={b} onClick={() => {
            const next = on ? data.strategyLayer.biases.filter((x) => x !== b) : [...data.strategyLayer.biases, b];
            set('strategyLayer.biases', next);
          }} className={`text-sm px-3 py-1.5 rounded-2xl border ${on ? 'bg-slate-100 border-slate-800' : 'hover:bg-slate-50'}`}>
            {b}
          </button>
        );
      })}
    </div>
  );

  const Review = () => (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Scope & Triage</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <div className="flex flex-wrap gap-2">
              {data.scope.needs.strategy && <Badge>Strategy</Badge>}
              {data.scope.needs.planning && <Badge>Planning</Badge>}
              {data.scope.needs.tactical && <Badge>Tactical</Badge>}
            </div>
            {data.scope.notes && <p className="text-sm text-slate-600">{data.scope.notes}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Business</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-1">
            <div><strong>Objective:</strong> {data.business.objective}</div>
            <div><strong>Market:</strong> {data.business.market}</div>
            <div><strong>Budget:</strong> {data.business.budget}</div>
            <div><strong>Key Dates:</strong> {data.business.keyDates}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Behaviour</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Row>
            <Field label="Today"> <Textarea value={data.behaviour.behaviourToday} onChange={(e) => set('behaviour.behaviourToday', e.target.value)} /> </Field>
            <Field label="Desired"> <Textarea value={data.behaviour.behaviourDesired} onChange={(e) => set('behaviour.behaviourDesired', e.target.value)} /> </Field>
          </Row>
          <Row>
            <Field label="Emotional barriers"> <Textarea value={data.behaviour.blockers.emotional} onChange={(e) => set('behaviour.blockers.emotional', e.target.value)} /> </Field>
            <Field label="Social barriers"> <Textarea value={data.behaviour.blockers.social} onChange={(e) => set('behaviour.blockers.social', e.target.value)} /> </Field>
          </Row>
          <Field label="Rational barriers"> <Textarea value={data.behaviour.blockers.rational} onChange={(e) => set('behaviour.blockers.rational', e.target.value)} /> </Field>
          <Separator/>
          <div className="space-y-3">
            <Label>Audience Segments</Label>
            <div className="grid gap-3">
              {data.behaviour.audienceSegments.map((a, i) => (
                <div key={i} className="rounded-2xl border p-3">
                  <div className="flex items-center justify-between"><strong>{a.name || `Segment ${i+1}`}</strong>
                    <Button variant="ghost" size="sm" onClick={() => removeAudience(i)}><Trash2 className="h-4 w-4"/>Remove</Button>
                  </div>
                  <div className="grid md:grid-cols-2 gap-3 mt-2 text-sm">
                    <div><span className="text-slate-500">Who:</span> {a.who}</div>
                    <div><span className="text-slate-500">Day in life:</span> {a.dayInLife}</div>
                    <div><span className="text-slate-500">Barriers:</span> {a.barriers}</div>
                    <div><span className="text-slate-500">Influencers:</span> {a.influencers}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {data.scope.needs.strategy && (
        <Card>
          <CardHeader><CardTitle>Strategy (Media as Growth Engine)</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-3">
            <div><strong>Ask media to:</strong>
              <div className="mt-2 flex flex-wrap gap-2">
                {Object.entries(data.strategyLayer.askMediaTo).filter(([,v])=>v).map(([k]) => (
                  <Badge key={k}>{k}</Badge>
                ))}
              </div>
            </div>
            <div><strong>PME focus:</strong> {Object.entries(data.strategyLayer.pmeFocus).filter(([,v])=>v).map(([k])=>k).join(', ')}</div>
            <div><strong>Biases to leverage:</strong> {data.strategyLayer.biases.join(', ')}</div>
            <div><strong>Organising idea:</strong><div className="mt-1 whitespace-pre-wrap">{data.strategyLayer.organisingIdea}</div></div>
          </CardContent>
        </Card>
      )}

      {data.scope.needs.planning && (
        <Card>
          <CardHeader><CardTitle>Planning (Media as Behavioural Designer)</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-3">
            <div className="grid md:grid-cols-2 gap-3">
              <div><strong>Sequencing:</strong><div className="mt-1 whitespace-pre-wrap">{data.planningLayer.sequencing}</div></div>
              <div><strong>Phasing:</strong><div className="mt-1 whitespace-pre-wrap">{data.planningLayer.phasing}</div></div>
              <div><strong>Channel mix:</strong><div className="mt-1 whitespace-pre-wrap">{data.planningLayer.channelMix}</div></div>
              <div><strong>Budget flexibility:</strong><div className="mt-1 whitespace-pre-wrap">{data.planningLayer.budgetFlex}</div></div>
            </div>
            <Separator/>
            <div className="grid md:grid-cols-2 gap-4">
              {(['awareness','consideration','conversion','retention','winback'] as JourneyStage[]).map((stage) => (
                <div key={stage} className="rounded-2xl border p-3">
                  <div className="font-medium capitalize">{stage}</div>
                  <div className="mt-2 text-sm"><span className="text-slate-500">Know:</span> {data.planningLayer.journeyJobs[stage].know}</div>
                  <div className="mt-1 text-sm"><span className="text-slate-500">Do:</span> {data.planningLayer.journeyJobs[stage].do}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {data.scope.needs.tactical && (
        <Card>
          <CardHeader><CardTitle>Tactical (Media as Friction Remover)</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-3">
            <div className="grid md:grid-cols-2 gap-3">
              <div><strong>Execute in-flight:</strong> {data.tacticalLayer.executeInFlight ? 'Yes' : 'No'}</div>
              <div><strong>Pre-defined channels:</strong> {data.tacticalLayer.preDefinedChannels ? 'Yes' : 'No'}</div>
              <div><strong>Performance KPIs only:</strong> {data.tacticalLayer.performanceKpisOnly ? 'Yes' : 'No'}</div>
              <div><strong>Test & Learn:</strong> {data.tacticalLayer.testAndLearn ? 'Yes' : 'No'}</div>
            </div>
            <div className="mt-2"><strong>Platform notes:</strong><div className="mt-1 whitespace-pre-wrap">{data.tacticalLayer.platformNotes}</div></div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>Media, Measurement & Governance</CardTitle></CardHeader>
        <CardContent className="text-sm space-y-3">
          <div className="grid md:grid-cols-2 gap-3">
            <div><strong>Paid / Owned / Earned:</strong><div className="mt-1 whitespace-pre-wrap">{data.media.paidOwnedEarned}</div></div>
            <div><strong>Contextual opportunities:</strong><div className="mt-1 whitespace-pre-wrap">{data.media.contextualOpps}</div></div>
            <div><strong>Existing assets:</strong><div className="mt-1 whitespace-pre-wrap">{data.media.assetsExisting}</div></div>
            <div><strong>Assets needed:</strong><div className="mt-1 whitespace-pre-wrap">{data.media.assetsNeeded}</div></div>
          </div>
          <Separator/>
          <div className="grid md:grid-cols-2 gap-3">
            <div><strong>Success measures:</strong><div className="mt-1 whitespace-pre-wrap">{data.measurement.success}</div></div>
            <div><strong>KPIs:</strong><div className="mt-1 whitespace-pre-wrap">{data.measurement.kpis}</div></div>
            <div><strong>Instrumentation:</strong><div className="mt-1 whitespace-pre-wrap">{data.measurement.instrumentation}</div></div>
            <div><strong>Cadence:</strong><div className="mt-1 whitespace-pre-wrap">{data.measurement.cadence}</div></div>
          </div>
          <Separator/>
          <div className="grid md:grid-cols-3 gap-3">
            <div><strong>Mandatories:</strong><div className="mt-1 whitespace-pre-wrap">{data.governance.mandatories}</div></div>
            <div><strong>Regions:</strong><div className="mt-1 whitespace-pre-wrap">{data.governance.regions}</div></div>
            <div><strong>Stakeholders:</strong><div className="mt-1 whitespace-pre-wrap">{data.governance.stakeholders}</div></div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Panels
  const panels: Record<string, JSX.Element> = {
    scope: (
      <StepShell title="Triage: What thinking do you need?" subtitle="Tick one or more — this controls which sections appear next and streamlines data capture.">
        <div className="grid md:grid-cols-3 gap-3">
          <label className="flex items-center gap-3 rounded-2xl border p-4">
            <Checkbox checked={data.scope.needs.strategy} onCheckedChange={(v) => set('scope.needs.strategy', !!v)} />
            <div>
              <div className="font-medium">Strategy</div>
              <p className="text-xs text-slate-600">Define/reframe behaviour & media’s long-term role.</p>
            </div>
          </label>
          <label className="flex items-center gap-3 rounded-2xl border p-4">
            <Checkbox checked={data.scope.needs.planning} onCheckedChange={(v) => set('scope.needs.planning', !!v)} />
            <div>
              <div className="font-medium">Planning</div>
              <p className="text-xs text-slate-600">Design roadmap: sequencing, channels, budget.</p>
            </div>
          </label>
          <label className="flex items-center gap-3 rounded-2xl border p-4">
            <Checkbox checked={data.scope.needs.tactical} onCheckedChange={(v) => set('scope.needs.tactical', !!v)} />
            <div>
              <div className="font-medium">Tactical</div>
              <p className="text-xs text-slate-600">Execute & optimise: placements, bids, formats.</p>
            </div>
          </label>
        </div>
        <Separator className="my-4"/>
        <Row>
          <Field label="Project name">
            <Input value={data.meta.projectName} onChange={(e)=>set('meta.projectName', e.target.value)} placeholder="e.g., TUA 2026 Domestic Growth"/>
          </Field>
          <Field label="Client / Brand">
            <Input value={data.meta.clientOrg} onChange={(e)=>set('meta.clientOrg', e.target.value)} placeholder="Client org"/>
          </Field>
        </Row>
        <Row>
          <Field label="Briefed by">
            <Input value={data.meta.briefedBy} onChange={(e)=>set('meta.briefedBy', e.target.value)} placeholder="Name(s)"/>
          </Field>
          <Field label="Response due">
            <Input value={data.meta.responseDue} onChange={(e)=>set('meta.responseDue', e.target.value)} placeholder="YYYY-MM-DD"/>
          </Field>
        </Row>
        <Field label="Notes (scope assumptions, worries, constraints)">
          <Textarea value={data.scope.notes} onChange={(e)=>set('scope.notes', e.target.value)} rows={3}/>
        </Field>
      </StepShell>
    ),
    business: (
      <StepShell title="Business Context" subtitle="What business outcome are we powering?">
        <Row>
          <Field label="Objective"><Textarea value={data.business.objective} onChange={(e)=>set('business.objective', e.target.value)} /></Field>
          <Field label="Market / Geography"><Input value={data.business.market} onChange={(e)=>set('business.market', e.target.value)} /></Field>
        </Row>
        <Row>
          <Field label="Total budget & split notes"><Input value={data.business.budget} onChange={(e)=>set('business.budget', e.target.value)} placeholder="e.g., $15m total; brand $5m / performance $10m (flex +/- 10%)"/></Field>
          <Field label="Key dates & milestones"><Textarea value={data.business.keyDates} onChange={(e)=>set('business.keyDates', e.target.value)} placeholder="Intake windows, bursts, blackouts, approvals"/></Field>
        </Row>
      </StepShell>
    ),
    behaviour: (
      <StepShell title="Behaviour Change" subtitle="Define the shift and who must change.">
        <Row>
          <Field label="Today (behaviour / mental model)"><Textarea value={data.behaviour.behaviourToday} onChange={(e)=>set('behaviour.behaviourToday', e.target.value)} placeholder="e.g., 'Private uni = expensive/less credible' → low shortlist"/></Field>
          <Field label="Desired (behaviour / outcome)"><Textarea value={data.behaviour.behaviourDesired} onChange={(e)=>set('behaviour.behaviourDesired', e.target.value)} placeholder="e.g., 'Torrens is first-choice, flexible and credible' → apply & enrol"/></Field>
        </Row>
        <Separator/>
        <Row>
          <Field label="Emotional barriers"><Textarea value={data.behaviour.blockers.emotional} onChange={(e)=>set('behaviour.blockers.emotional', e.target.value)} /></Field>
          <Field label="Social barriers"><Textarea value={data.behaviour.blockers.social} onChange={(e)=>set('behaviour.blockers.social', e.target.value)} /></Field>
        </Row>
        <Field label="Rational barriers"><Textarea value={data.behaviour.blockers.rational} onChange={(e)=>set('behaviour.blockers.rational', e.target.value)} /></Field>
        <Separator/>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label>Audience segments</Label>
            <Button size="sm" variant="outline" onClick={addAudience}><Plus className="h-4 w-4"/>Add segment</Button>
          </div>
          <div className="grid gap-3">
            {data.behaviour.audienceSegments.map((a, i) => (
              <div className="rounded-2xl border p-4" key={i}>
                <Row>
                  <Field label="Segment name"><Input value={a.name} onChange={(e)=>{ const arr = [...data.behaviour.audienceSegments]; arr[i].name = e.target.value; set('behaviour.audienceSegments', arr); }}/></Field>
                  <Field label="Who (demographics/attitudes/behaviours)"><Textarea value={a.who} onChange={(e)=>{ const arr = [...data.behaviour.audienceSegments]; arr[i].who = e.target.value; set('behaviour.audienceSegments', arr); }} /></Field>
                </Row>
                <Row>
                  <Field label="Day in the life / where attention happens"><Textarea value={a.dayInLife} onChange={(e)=>{ const arr = [...data.behaviour.audienceSegments]; arr[i].dayInLife = e.target.value; set('behaviour.audienceSegments', arr); }} /></Field>
                  <Field label="Barriers & Influencers"><Textarea value={a.barriers} onChange={(e)=>{ const arr = [...data.behaviour.audienceSegments]; arr[i].barriers = e.target.value; set('behaviour.audienceSegments', arr); }} /></Field>
                </Row>
                <div className="flex justify-end">
                  <Button variant="ghost" size="sm" onClick={() => removeAudience(i)}><Trash2 className="h-4 w-4"/>Remove</Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </StepShell>
    ),
    strategy: (
      <StepShell title="Strategy (if selected)" subtitle="Media’s strategic job to unlock growth.">
        <Field label="What are we asking media to do (tick all)"><StrategyHints/></Field>
        <Row>
          <Field label="PME focus (Perception / Motivation / Enablement)"><PMESelector/></Field>
          <Field label="Biases & heuristics to leverage"><BiasSelector/></Field>
        </Row>
        <Field label="Organising idea (optional)"><Textarea value={data.strategyLayer.organisingIdea} onChange={(e)=>set('strategyLayer.organisingIdea', e.target.value)} placeholder="e.g., Make flexible study feel like the smart default"/></Field>
      </StepShell>
    ),
    planning: (
      <StepShell title="Planning (if selected)" subtitle="Design the decision architecture: sequencing, phasing, channels.">
        <Row>
          <Field label="Sequencing (message flow across stages)"><Textarea value={data.planningLayer.sequencing} onChange={(e)=>set('planningLayer.sequencing', e.target.value)} placeholder="e.g., Jolt → Translate for trust → Enable action"/></Field>
          <Field label="Phasing (calendar, bursts, recency)"><Textarea value={data.planningLayer.phasing} onChange={(e)=>set('planningLayer.phasing', e.target.value)} placeholder="e.g., Q4 heavy-up to prime T1 intake; always-on search"/></Field>
        </Row>
        <Row>
          <Field label="Channel mix & roles"><Textarea value={data.planningLayer.channelMix} onChange={(e)=>set('planningLayer.channelMix', e.target.value)} placeholder="High-attention video for salience; creators for social proof; search/retargeting for enablement"/></Field>
          <Field label="Budget flexibility & governance"><Textarea value={data.planningLayer.budgetFlex} onChange={(e)=>set('planningLayer.budgetFlex', e.target.value)} placeholder="e.g., Flex +/- 10% between brand/performance; reallocation rules for CPE deltas"/></Field>
        </Row>
        <Separator/>
        <Label>Journey jobs (Know/Do by stage)</Label>
        <div className="grid md:grid-cols-2 gap-4 mt-2">
          {(Object.keys(data.planningLayer.journeyJobs) as JourneyStage[]).map((stage) => (
            <div className="rounded-2xl border p-4" key={stage}>
              <div className="font-medium capitalize mb-2">{stage}</div>
              <Field label="Know"><Textarea value={data.planningLayer.journeyJobs[stage].know} onChange={(e)=>{ const next = { ...data.planningLayer.journeyJobs, [stage]: { ...data.planningLayer.journeyJobs[stage], know: e.target.value } }; set('planningLayer.journeyJobs', next); }} /></Field>
              <Field label="Do"><Textarea value={data.planningLayer.journeyJobs[stage].do} onChange={(e)=>{ const next = { ...data.planningLayer.journeyJobs, [stage]: { ...data.planningLayer.journeyJobs[stage], do: e.target.value } }; set('planningLayer.journeyJobs', next); }} /></Field>
            </div>
          ))}
        </div>
      </StepShell>
    ),
    tactics: (
      <StepShell title="Tactical (if selected)" subtitle="Execution, optimisation, and platform detail.">
        <div className="grid md:grid-cols-2 gap-3">
          <label className="flex items-center gap-3 rounded-2xl border p-3">
            <Switch checked={data.tacticalLayer.executeInFlight} onCheckedChange={(v)=>set('tacticalLayer.executeInFlight', !!v)} />
            <div>
              <div className="font-medium">Execute & optimise in-flight</div>
              <p className="text-xs text-slate-600">Within agreed rules & learning agenda.</p>
            </div>
          </label>
          <label className="flex items-center gap-3 rounded-2xl border p-3">
            <Switch checked={data.tacticalLayer.preDefinedChannels} onCheckedChange={(v)=>set('tacticalLayer.preDefinedChannels', !!v)} />
            <div>
              <div className="font-medium">Channels pre-defined by client</div>
              <p className="text-xs text-slate-600">If yes, we’ll focus on optimisation not selection.</p>
            </div>
          </label>
          <label className="flex items-center gap-3 rounded-2xl border p-3">
            <Switch checked={data.tacticalLayer.performanceKpisOnly} onCheckedChange={(v)=>set('tacticalLayer.performanceKpisOnly', !!v)} />
            <div>
              <div className="font-medium">Performance KPIs only</div>
              <p className="text-xs text-slate-600">CPC/CPA/CPE, vs leading indicators.</p>
            </div>
          </label>
          <label className="flex items-center gap-3 rounded-2xl border p-3">
            <Switch checked={data.tacticalLayer.testAndLearn} onCheckedChange={(v)=>set('tacticalLayer.testAndLearn', !!v)} />
            <div>
              <div className="font-medium">Test & learn agenda</div>
              <p className="text-xs text-slate-600">A/Bs, incrementality, creative variants.</p>
            </div>
          </label>
        </div>
        <Separator className="my-4"/>
        <Field label="Platform / placement notes (e.g., Meta vs TikTok, BVOD, Search)">
          <Textarea value={data.tacticalLayer.platformNotes} onChange={(e)=>set('tacticalLayer.platformNotes', e.target.value)} />
        </Field>
      </StepShell>
    ),
    media: (
      <StepShell title="Media, Assets & Context" subtitle="Channels, partners, and creative requirements we should plan around.">
        <Row>
          <Field label="Paid / Owned / Earned plan (high level)"><Textarea value={data.media.paidOwnedEarned} onChange={(e)=>set('media.paidOwnedEarned', e.target.value)} /></Field>
          <Field label="Contextual & partner opportunities"><Textarea value={data.media.contextualOpps} onChange={(e)=>set('media.contextualOpps', e.target.value)} /></Field>
        </Row>
        <Row>
          <Field label="Existing assets"><Textarea value={data.media.assetsExisting} onChange={(e)=>set('media.assetsExisting', e.target.value)} /></Field>
          <Field label="Assets needed"><Textarea value={data.media.assetsNeeded} onChange={(e)=>set('media.assetsNeeded', e.target.value)} /></Field>
        </Row>
      </StepShell>
    ),
    measurement: (
      <StepShell title="Measurement & Governance" subtitle="Define success and how we’ll track it.">
        <Row>
          <Field label="Success (behavioural outcomes)"><Textarea value={data.measurement.success} onChange={(e)=>set('measurement.success', e.target.value)} placeholder="Beyond clicks: e.g., shortlist rate, webinar sign-ups, applications"/></Field>
          <Field label="KPIs & leading indicators"><Textarea value={data.measurement.kpis} onChange={(e)=>set('measurement.kpis', e.target.value)} placeholder="e.g., prompted awareness, search volume, site depth, CPE"/></Field>
        </Row>
        <Row>
          <Field label="Instrumentation (tags, pixels, CRM, MMM/MT)"><Textarea value={data.measurement.instrumentation} onChange={(e)=>set('measurement.instrumentation', e.target.value)} /></Field>
          <Field label="Cadence & optimisation loops"><Textarea value={data.measurement.cadence} onChange={(e)=>set('measurement.cadence', e.target.value)} placeholder="e.g., weekly sprints, monthly readouts, intake post-mortems"/></Field>
        </Row>
        <Separator/>
        <Row>
          <Field label="Mandatories (legal, brand, accessibility)"><Textarea value={data.governance.mandatories} onChange={(e)=>set('governance.mandatories', e.target.value)} /></Field>
          <Field label="Regions / Stakeholders"><Textarea value={data.governance.regions} onChange={(e)=>set('governance.regions', e.target.value)} placeholder="Geos, languages, key approvers"/></Field>
        </Row>
        <Field label="Stakeholders & RACI"><Textarea value={data.governance.stakeholders} onChange={(e)=>set('governance.stakeholders', e.target.value)} placeholder="Who leads strategy / planning / performance / creative"/></Field>
      </StepShell>
    ),
    review: (
      <StepShell title="Review & Print" subtitle="Everything in one place. Use Print to PDF for client-ready share.">
        <Review />
      </StepShell>
    ),
  };

  const CurrentPanel = panels[visibleSteps[stepIdx].id];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-slate-50 print:bg-white">
      {renderHeader()}

      <div className="max-w-6xl mx-auto px-4 py-6 print:py-2">
        <div className="print:hidden grid grid-cols-1 md:grid-cols-12 gap-4 mb-6">
          <Card className="md:col-span-3">
            <CardHeader className="pb-2"><CardTitle className="text-base">Steps</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {visibleSteps.map((s, i) => (
                <button key={s.id} onClick={() => setStepIdx(i)} className={`w-full text-left px-3 py-2 rounded-xl border flex items-center gap-2 ${i===stepIdx? 'border-black bg-slate-50':'hover:bg-slate-50'}`}>
                  {s.icon}
                  <span className="text-sm">{s.label}</span>
                </button>
              ))}
            </CardContent>
          </Card>

          <div className="md:col-span-9 space-y-4">
            <AnimatePresence mode="wait">
              <motion.div key={activeId} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }}>
                {CurrentPanel}
              </motion.div>
            </AnimatePresence>
            <StepControls />
          </div>
        </div>

        <div className="hidden print:block">
          <h1 className="text-2xl font-semibold mb-4">Behavioural Media Brief</h1>
          <Review />
        </div>
      </div>

      <style jsx global>{`
        @media print { .print\:hidden { display: none !important; } .print\:block { display: block !important; } body { background: white !important; } }
      `}</style>
    </div>
  );
}
