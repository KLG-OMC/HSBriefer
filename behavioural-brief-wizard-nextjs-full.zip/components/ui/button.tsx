import * as React from 'react';
export function Button({ className = '', variant = 'default', size = 'md', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default'|'outline'|'ghost'|'secondary'; size?: 'sm'|'md'|'lg' }) {
  const variants = {
    default: 'bg-black text-white border-black',
    outline: 'bg-white text-black border-slate-300',
    ghost: 'bg-transparent text-black border-transparent',
    secondary: 'bg-slate-100 text-black border-slate-300'
  } as const;
  const sizes = { sm: 'px-3 py-2 text-sm', md: 'px-4 py-2', lg: 'px-5 py-3' } as const;
  return <button className={`inline-flex items-center gap-2 border rounded-2xl ${variants[variant]} ${sizes[size]} ${className}`} {...props} />
}
