import * as React from 'react';
export function Badge({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <span className={`inline-block bg-slate-100 border border-slate-300 text-slate-800 px-2.5 py-1 rounded-full text-xs ${className}`}>{children}</span>
}
