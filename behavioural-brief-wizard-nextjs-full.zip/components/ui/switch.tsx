import * as React from 'react';
export function Switch({ checked, onCheckedChange }: { checked?: boolean; onCheckedChange?: (v: boolean)=>void }) {
  return (
    <button
      onClick={()=>onCheckedChange?.(!checked)}
      className={`w-10 h-6 rounded-full transition border ${checked? 'bg-black border-black':'bg-slate-200 border-slate-300'}`}
      aria-pressed={checked}
      type="button"
    >
      <span className={`block w-5 h-5 bg-white rounded-full translate-x-0.5 transition ${checked? 'translate-x-[18px]':''}`}></span>
    </button>
  );
}
