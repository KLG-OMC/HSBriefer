import * as React from 'react';
export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="w-full min-h-[86px] border border-slate-300 rounded-xl px-3 py-2" {...props} />
}
