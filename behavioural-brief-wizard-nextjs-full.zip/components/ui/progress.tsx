import * as React from 'react';
export function Progress({ value = 0 }: { value?: number }) {
  return (
    <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
      <i className="block h-full bg-gradient-to-r from-sky-400 to-blue-600" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}
